import { Component, OnInit } from '@angular/core';
import { ClientService } from '../client.service';
import { Router } from '@angular/router';
import { BillService } from '../bill.service';
import { NgForm } from '@angular/forms';


@Component({
  selector: 'app-billable-details',
  templateUrl: './billable-details.component.html',
  styleUrls: ['./billable-details.component.css']
})
export class BillableDetailsComponent implements OnInit {
  items: any=[];
  packageDetails: any;
  clients: any;

  constructor(private service: BillService, private router: Router) {
    this.getBillable();
  }
  
  getBillable() {
    let getmyVal: any = JSON.parse(localStorage.getItem("billables"));
    console.log('step-2::', getmyVal);
    this.clients = getmyVal;
    console.log('step-3::',this.clients.listBill);
    this.clients = this.clients.listBill;
  } 

  delete(data) {
    console.log('my data::',data)
    this.service.deleteClientData(data).subscribe(res => {
      console.log(res);
      console.log('data deleted')
      this.getBillable();
      this.router.navigateByUrl("/billdata")
    })
  }
  update(data) {
    console.log(data);
    console.log('data updated')
    this.service.selectedBillable = data;   
    this.router.navigateByUrl("/billable");
  }
  
  printPackageDetails(form: NgForm) {
    console.log('package details::',form.value);
    this.service.postDataPack(form.value).subscribe(results => {
      console.log('pakageinfo',results);
      this.clients = results;
      form.reset();
      this.router.navigateByUrl("/pakdetails")
    }, (err) => {
      console.log(err);
    }, () => {
      console.log("data inserted successfully");
    })
  } 

  getPackageForm(data) {
    console.log('step-4::',data)
   this.packageDetails = data;
   console.log('step-5::', this.packageDetails)

  }

  ngOnInit() {
   

  }

}