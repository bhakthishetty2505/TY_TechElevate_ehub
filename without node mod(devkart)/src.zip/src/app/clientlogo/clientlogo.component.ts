import { Component, OnInit } from '@angular/core';
import { ClientService } from '../client.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-clientlogo',
  templateUrl: './clientlogo.component.html',
  styleUrls: ['./clientlogo.component.css']
})
export class ClientlogoComponent implements OnInit {

  clients:any;
  countList: any;
  countEmp: any;
  constructor(private service : ClientService, private route: Router) { 
    this.getData();
    this. getEmpCount();

  }

  getData() {
    this.service.getClientData().subscribe(res => {
      this.clients = res;
      this.clients = this.clients.listclients;
    
    })
  }

  getEmpCount(){
    this.service.getCount().subscribe(data => {
      this.countEmp = data;
      this.countEmp = this.countEmp.countMap;
    
     
    });
  }
  chartData(clientId) {
   
    this.service.getDetailsWithId(clientId).subscribe(responce=>{
      console.log('step-1 with id::'+responce);
      localStorage.setItem('results', JSON.stringify(responce));
    })
     this.service.getStackDeatis(clientId).subscribe (stackCount => {
      console.log('step2- count stack::', stackCount)
      localStorage.setItem('countStack', JSON.stringify(stackCount));
    })
     this.service.getYearList(clientId).subscribe(expCountList=>{
        console.log('step-3 year wise::',expCountList)
        localStorage.setItem('yearMap', JSON.stringify(expCountList));
       })
   
  this.route.navigateByUrl("/clidata");
  }

  getBillables(clientId) {
   this.service.getEmpDetailsWithId(clientId).subscribe(empDeatis =>{
     console.log('step-1::',empDeatis)
      localStorage.setItem('billables', JSON.stringify(empDeatis));
      this.route.navigateByUrl('/billdata');
    })


    
  }

  

  ngOnInit() {
  }

}
