import { Component, OnInit } from '@angular/core';
import { HttpClientModule, HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-clientrevenue',
  templateUrl: './clientrevenue.component.html',
  styleUrls: ['./clientrevenue.component.css']
})
export class ClientrevenueComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
